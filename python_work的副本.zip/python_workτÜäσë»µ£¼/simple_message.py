a="hello world" 
print ("language:\n\tpython\n\tjavascript")
