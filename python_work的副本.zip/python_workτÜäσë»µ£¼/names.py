# -*- coding:utf-8 -*-
num=["bishengke","kfc","mdl"]
for i in num:
	print( "i like pepperoni pizza "+"in "+i)
	
print("i really like pizza")	

animails=["hashiqi","cat","rabbit"]
for x in animails:
	print("a "+x+" would make a great pet !")
	
print("any  of these animails would like make a great pet!")	
