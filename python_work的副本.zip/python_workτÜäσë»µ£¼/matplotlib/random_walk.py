# -*- coding:utf-8 -*-
from random import choice
class RandomWalk():
	"""一个生成随机漫步的类"""
	def __init__(self,num_points=5000):
		self.num_points=num_points
		
		#所有随机漫步始于(0,0)
		self.x_values=[0]
		self.y_values=[0]
		
	def fill_walk(self):
		"""计算随机漫步的所有点"""
		#不断漫步直到指定的漫步次数
		while len(self.x_values) < self.num_points:
			#定义x轴和y轴的一次移动距离方向
			x_direction=choice([1,-1])
			x_distance=choice([0,1,2,3,4])
			x_step=x_direction*x_distance
			
			y_direction=choice([1,-1])
			y_distance=choice([0,1,2,3,4])
			y_step=y_direction*y_distance
			#如果没有移动，跳过不更新位置
			if x_step == 0 and y_step == 0:
				continue
			#本次移动之后圆点位置的x,y值	
			next_x=self.x_values[-1]+x_step
			next_y=self.y_values[-1]+y_step
			#x,y值的列表越来越多
			self.x_values.append(next_x)
			self.y_values.append(next_y)
						
	
		
