# -*- coding:utf-8 -*-
alien_color=["green","red","yellow"]
for alien in alien_color:
    if alien=="green":
        print("玩家获得5个点")
    elif alien not in alien_color:
	    print("玩家获得10个点")	
    elif alien=="red":
        print("玩家获得15个点")
