first_name="xie"
last_name="jun"
full_name=first_name + " " + last_name
message="hello,"+ full_name.title() +"!"
print (message)
