import json #导入python 中的json模块
l =['iplaypython',[1,2,3],{'name':'xiaoming'}] #创建一个l列表
encoded_json = json.dumps(l) # 将l列表，进行json格式化编码
print(repr(l))
print(type(encoded_json))
print(encoded_json) #输出结果

decode_json = json.loads(encoded_json)
print(type(decode_json)) #查看一下解码后的对象类型
print(decode_json) #输出结果
