import csv
from matplotlib import pyplot as plt
from datetime import datetime
filename='death_valley_2014.csv'
#快捷打开文件，自动关闭文件
with open(filename) as f:
	reader=csv.reader(f)
	#返回文件第一行
	header_row=next(reader)
	
	for index,column_header in enumerate(header_row):
		print(index,column_header)
	
	#从文件中获取最高气温
	highs=[]
	dates=[]
	lows=[]
	for row in reader:
		try:
			current_date=datetime.strptime(row[0],'%Y-%m-%d')
			high=int(row[1])		
			low=int(row[3])
		except ValueError:
			print(current_date,'missing data')
		else:		
			lows.append(low)
			highs.append(high)
			dates.append(current_date)
	
	#绘制图形像素128，图形尺寸
	fig=plt.figure(dpi=128,figsize=(10,6))
	plt.plot(dates,lows,c='blue',alpha=0.5)
	plt.plot(dates,highs,c='red',alpha=0.5)
	#曲线图颜色填充，透明度为0.1，几乎透明
	plt.fill_between(dates,highs,lows,facecolor='blue',alpha=0.1)
	plt.title("Daily low-high temperatures,2014",fontsize=24)
	plt.xlabel("date",fontsize=16)
	#让日期标签不重叠
	fig.autofmt_xdate()
	plt.ylabel("Temperatures (F)",fontsize=16)
	plt.tick_params(axis='both',which='major',labelsize=16)
	plt.show()

