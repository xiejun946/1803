# -*- coding:utf-8 -*-
class Restaurant():
    def __init__(self,restaurant_name,cuisine_type):
        self.restaurant_name=restaurant_name
        self.cuisine_type=cuisine_type
        self.number_serverd=0
    def set_number_serverd(self,num):
        self.number_serverd=num
        
    def increment_number_serverd(self,num1):
        self.number_serverd+=num1		
		   
        
    def describe_restaurant(self):
	    print(self.restaurant_name)
	    print(self.cuisine_type)
	    print(str(self.number_serverd)+' people have dinner at here') 
	    """打印出有多少人在用餐"""  	  
        
    
    def open_restaurant(self):
	    print('餐馆正在营业欢迎光临')
	    
	    
		
restaurant=Restaurant('xiexiansheng','food')
restaurant.describe_restaurant()
restaurant.open_restaurant()
print(restaurant.restaurant_name)
print(restaurant.cuisine_type)
restaurant.set_number_serverd(10)
restaurant.describe_restaurant()
restaurant.increment_number_serverd(2)
restaurant.describe_restaurant()
		
print('his fullname is '+full_name)
