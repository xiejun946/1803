#coding: utf-8
from xj_pycurl import Web_test
from xj_stmp import sendmail
from time import sleep

with open('/Users/admin/Downloads/python_work/autoyunwei/fikker_list.txt') as f:
   
	for URL in f:
		URL=URL.strip()
		print URL
		try:
			http_code=Web_test(URL)
		except:
			sendmail(URL)	
			
		else:
			if http_code != 200:
				sendmail(URL)
		
			
	
