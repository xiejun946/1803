# -*- coding:utf-8 -*-
#�����������͵��˷����б�
L=["tutu","beibei","laohao"]
person=L.pop(0)
L.insert(0,"siwei")
L.append("xixi")
L.insert(3,"hha")
L.insert(1,"xiha")
print (L)
K=L[-2:]	  
print(K)
for x in L[:4]:
	message="i am sorry ,but i can not have dinner with you,"+x+"!"
	print(message) 	    
for i in K:
	yaoqing="would you like have dinner with me "+i+"?"
	print (yaoqing)


	  
	  
	  
	  

