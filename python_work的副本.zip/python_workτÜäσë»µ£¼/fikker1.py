# -*- coding:utf-8 -*-
import webbrowser
import os,time
webbrowser.open("C:\Program Files (x86)\Google\Chrome\Application\chrome.exe")
#webbrowser.open("C:\Program Files (x86)\Google\Chrome\Application\chrome.exe")
#webbrowser.open('http://107.150.125.243:1280/fikcdn/admin/main.php')
action=webbrowser.open('http://107.150.125.243:1280/fikcdn/admin/main.php')
webbrowser.get()
webbrowser.register()	
	
	
    	
	
	
