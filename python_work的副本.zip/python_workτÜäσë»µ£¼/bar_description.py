import pygal
from pygal.style import LightenStyle as LS,LightColorizedStyle as LCS
my_style=LS('#336676',base_style=LCS)
my_config=pygal.Config()
my_config.x_label_rotation=45
my_config.show_lengend=False
chart=pygal.Bar(my_config,style=my_style)
chart.title='Pyhton Projects'
chart.x_labels=['httpie','django','flask']

plot_dicts=[
		{'value': 16101,'label': 'Description of httpie'},
		{'value': 15028,'label': 'Description of django'},
		{'value': 14798,'label': 'Description of flask'},
			]
		
chart.add('',plot_dicts)
chart.render_to_file('bar_description.svg')			
