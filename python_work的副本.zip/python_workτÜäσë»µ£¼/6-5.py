# -*- coding:utf-8 -*-
rivers={
    "nile": "egypt",
    "changjiang": "china",
    "genghe": "india"      

}
for river,country in rivers.items():
	print("The "+river.title()+" runs through "+country.title())
	
for r in rivers.keys():
    print(r.title())		

for c in rivers.values():
	print(c.title())

L=["nile","changjiang","xx"]


for name in L:
	if name in rivers.keys():
		print(" thank you for come here!")
	else:
		print("please come to survey "+name)	
