import math
class Xiejun():
	def __init__(self,num):
		self.num=num
     
    
ligang=Xiejun(3)
print(hasattr(ligang,'num'))
print(hash(1))     
print(id('ss'))
     
print(isinstance(3,int))
print(locals())
print(max(3,4,5))
print(object())
print(hex(2))     #16进制
print(oct(3))     #8进制
print(bin(2))     #2进制
x=open('1.txt','r')
print(x.readlines())
x.close()
print(math.pow(2,3))
print(property(ligang.num))
print(round(2.3456,3))
a=list(range(10))
x=slice(1,5,2)
print(a[x])
