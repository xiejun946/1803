import requests
import btc_close_2017 as btc
json_url='http://raw.githubusercontent.com/muxuezi/btc/master/btc_close_2017.json'
#用get方法得到数据
req=requests.get(json_url)
type(req.text)
#写入数据
with open('btc_close_2017_request.json','w') as f:
	f.write(req.text)
#用json格式处理请求的数据	
file_requests=req.json()
#比较是否二种内容相同
print(btc.file_urllib==file_requests)	

