# -*- coding:utf-8 -*-
cities={
    "wuhan": {"country": "china",
    "population": 1300000000,
    "fact": "hot"}
    ,   
    "nanjing": {"country": "china",
    "population": 1300000000,
    "fact": "hot"}
    ,
    "beijing": {"country": "china",
    "population": 1300000000,
    "fact": "dry"}




    }
for k,v in cities.items():
	print("the infomation of "+k+":")
	print(v)
