message="one of python's strengths is its diverse community,"
print (message)
