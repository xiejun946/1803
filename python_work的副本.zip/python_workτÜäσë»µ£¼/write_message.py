# -*- coding:utf-8 -*-
filename='text_files\programming.txt'
with open(filename,'w') as file_object:
	file_object.write('I Love programming.\n')
	file_object.write('I love a new games\n')
	
	
