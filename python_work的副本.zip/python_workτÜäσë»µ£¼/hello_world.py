message="hello world"
print (message)
message="hello python world"
print (message)
