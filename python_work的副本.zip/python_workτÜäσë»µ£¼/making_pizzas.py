# -*- coding:utf-8 -*-
from pizza import *
make_pizza("pepperoni")
make_pizza("mushrooms","green peppers","extra cheese")
