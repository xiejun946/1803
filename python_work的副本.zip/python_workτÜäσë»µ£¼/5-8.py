# -*- coding:utf-8 -*-
names=["admin","guest","xiejun","tutu","gogo"]
if names:
    for people in names:
	    if people=="admin":
		    print("Hello admin,would you like to see a status report?")
	    else:
	        print("Hello Eric,Thank you for logging in again")	
else:
	print("we need to find some users!")
