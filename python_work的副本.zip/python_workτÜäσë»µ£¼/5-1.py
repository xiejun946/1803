# -*- coding:utf-8 -*-
a="xiaobi"
b="Xiaobi"
if a.lower()==b.lower():
	print("a==b")
else:
    print("no")	
x=101
y=100
if x>y and x==y:
	print("yes")
else:
	print("!")	
L=[2,3,45]
if 1 not in L:
	print("1 is not in the list")
print("年后")
