# -*- coding:utf-8 -*-
penny={
    "type": "buru",
    "master": "me"   
    }
    
yao={
    "type": "human",
    "master": "me"
    }    


pets=[penny,yao]

for pet in pets:
	print(pet)

