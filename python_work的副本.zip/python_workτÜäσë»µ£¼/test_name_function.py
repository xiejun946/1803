# -*- coding:utf-8 -*-
import unittest
from name_function import get_formatted_name
class NameTestCase(unittest.TestCase):
	"""
	test name_function.py
	"""
	def test_first_last_name(self):
		"""能够正确处理像janis joplin这样的姓名吗？"""
		formatted_name=get_formatted_name('janis','joplin')
		self.assertEqual(formatted_name,'Janis Joplin')
		
	def test_fitst_last_middle_name(self):
		"""
		能够正确处理像WOLF这样的姓名吗？
		"""	
		formatted_name=get_formatted_name('wolfgang','mozart','amadeus')
		self.assertEqual(formatted_name,'Wolfgang Amadeus Mozart')
		
unittest.main()		
