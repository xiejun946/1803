# -*- coding:utf-8 -*-
import smtplib
import string
def sendmail(URL):
	HOST="smtp.gmail.com"
	SUBJECT="Test eamil form python"
	TO="xiejun19891414@163.com"
	FROM="xiejun19891414@gmail.com"
	text="这个fikker服务器出现问题了请尽快查看: "+URL
	BODY=string.join(("FROM: %s"  % FROM,
					"TO: %s" % TO,
					"Subject: %s" % SUBJECT,
					"",
					text,
					),"\r\n")
	
	server=smtplib.SMTP() #建立smtp服务器对象
	server.connect(HOST,"587") #连接服务器
	#server.ehlo()
	#openssl s_client -connect HOST:465 
	server.starttls()    #启动安全传输模式
	server.login("xiejun19891414@gmail.com","xiejun51866230")  #登录邮箱
	server.sendmail(FROM,TO,BODY)   #发送邮件
	server.quit()     #退出smtp连接


