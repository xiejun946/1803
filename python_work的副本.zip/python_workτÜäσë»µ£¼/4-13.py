# -*- coding:utf-8 -*-
foods=("noodles","yabo","xiaolongxia","pangxiejia","wuchangyu")
foods=("xixi","haha","xiaolongxia","pangxiejia","wuchangyu")

for i in foods:
  print(i)

