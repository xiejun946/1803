# -*- coding:utf-8 -*-
favorite_num={
    "me": [3,7],
    "tutu": [8,6],
    "laobei": [9],
    "laohao": [4],
    "siwei": [6]
    }

for name,nums in favorite_num.items():
	print(name+" favorite num is")
	for num in nums:
		print(num)  
