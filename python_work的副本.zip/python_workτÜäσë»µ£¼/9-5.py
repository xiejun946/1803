# -*- coding:utf-8 -*-
class User():
	def __init__(self,first,last,age):
		self.first_name=first
		self.last_name=last
		self.age=age
		"""describe"""
		self.full_name=self.first_name.title()+' '+self.last_name.title()
		self.login_attempts=0
		
	def increment_login_attempts(self):
		self.login_attempts+=1
		
		
	def reset_login_attempts(self):
		self.login_attempts=0		
		
		
		
	
	def describe_user(self):	    
		print('his firstname is '+self.first_name)
		print('his lastname is '+self.last_name)
		print('his fullname is '+self.full_name)
		print('his age is '+str(self.age))
		print(self.login_attempts)
		"""greet"""
	def greet_user(self):
		print('hello '+self.full_name+',merry christmas!')
		

lilei=User('li','lei',21)
lilei.describe_user()
lilei.greet_user()		
lilei.increment_login_attempts()
lilei.increment_login_attempts()
lilei.increment_login_attempts()
print(lilei.login_attempts)	
lilei.reset_login_attempts()
print(lilei.login_attempts)
				
