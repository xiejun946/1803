# -*- coding:utf-8 -*-
import pygame
import sys
from settings import Settings
from ship import Ship
import game_functions as gf
from pygame.sprite import Group
from game_stats import GameStats
from button import Button
from scoreboard import Scoreboard
def run_game():
	#初始化游戏并创建一个屏幕对象
	pygame.init()
	#初始化静态设置数据
	ai_settings=Settings()
	
	screen=pygame.display.set_mode((ai_settings.screen_width,ai_settings.screen_height))
	pygame.display.set_caption("Alien Invasion")
	#bg_color=(ai_settings.bg_color)
	#实例化ship
	ship=Ship(ai_settings,screen)
	#建议用于存储游戏统计信息的实例
	stats=GameStats(ai_settings)
	#初始化得分板
	sb=Scoreboard(ai_settings,screen,stats)
	
	play_button=Button(ai_settings,screen,"PLAY")
		
	#创建一个用于存储子弹的编组	
	bullets=Group()
	#创建一个用于存储外星人的编组
	aliens=Group()
	#创建外星人群
	gf.create_fleet(ai_settings,screen,ship,aliens)
	
	#开始游戏的主循环
	while True:
		#监视键盘鼠标的事件
		gf.check_events(ai_settings,screen,stats,play_button,ship,
		aliens,bullets,sb)
		if stats.game_active:
		#控制飞船移动行为
			ship.update()
			
			#删除已经消失的子弹减少内存消耗,并保持子弹最多3颗
			gf.update_bullets(ai_settings,screen,ship,bullets,aliens,
			sb,stats)
			#更新外星人的位置
			gf.update_aliens(ai_settings,stats,screen,ship,
			aliens,bullets,sb)
		
		#负责屏幕更新代码块		
		gf.update_screen(ai_settings,screen,stats,ship,bullets,aliens,
		play_button,sb)
		
run_game()





	








			


