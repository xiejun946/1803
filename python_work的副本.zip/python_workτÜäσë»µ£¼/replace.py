# -*- coding:utf-8 -*-
def replace_words(file,oldword,newword):
    content = ''
    f = open(file)
    f.seek(0,0) #鼠标指针放在开头
    for lines in f.readlines():
        if oldword in lines:
            lines_new=lines.replace(oldword,newword)
            content+=lines_new
    f = open(file,'w')
    f.write(content)
    f.close()
   
replace_words('2.txt','q','h')    
