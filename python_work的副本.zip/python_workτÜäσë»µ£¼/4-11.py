# -*- coding:utf-8 -*-
pizza=["bishengke","kfc","mld"]
friend_pizza=pizza[:]
pizza.append("buzhidao")
friend_pizza.append("nicai")
print("my favorite pizzas are")
for i in pizza:
	print(i)
	
print("my friends favorite pizzas are")
for x in friend_pizza:
	print(x)	
