a="hello world"
print (a)
a="hello python world"
print (a)
