# -*- coding:utf-8 -*-
chb={
    "append": "append in the end of the list",
    "pop": "delete value in the list",
    "del": "delete",
    "remove": "delete the value",
    "reverse": "perment modify the list of show"
    }
    
for k,v in chb.items():   
    print(k.title()+" the mean is "+v.lower())    
