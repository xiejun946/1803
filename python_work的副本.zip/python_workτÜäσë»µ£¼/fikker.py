# -*- coding:utf-8 -*-
import time
from selenium import webdriver
def mac():
    driver = webdriver.Chrome()
    driver.implicitly_wait(5)
    driver.get("http://107.150.125.243:1280/fikcdn/admin/main.php")
    
mac()    

