import json
import pygal
import math
from itertools import groupby
#将数据加载到一个列表中
filename='btc_close_2017.json'
with open(filename) as f:
	btc_data=json.load(f)
dates,months,weeks,weekdays,close=[],[],[],[],[]


	
for btc_dict in btc_data:
	dates.append(btc_dict['date'])
	months.append(int(btc_dict['month']))
	weeks.append(int(btc_dict['week']))
	weekdays.append(btc_dict['weekday'])
	close.append(int(float(btc_dict['close'])))
	#print("{} is month {} week {} ,{},the close price is {}".format(date,month,week,weekday,close))
	
line_chart=pygal.Line(x_label_rotation=20,show_minor_x_labels=False)
line_chart.title='收盘价对手变换(￥)'
line_chart.x_labels=dates
#每20天显示一次
N=20
line_chart.x_labels_major=dates[::N]
close_log=[math.log10(x) for x in close]
line_chart.add('log收盘价',close_log)
line_chart.render_to_file('收盘价曲线图log (￥).svg')
		

