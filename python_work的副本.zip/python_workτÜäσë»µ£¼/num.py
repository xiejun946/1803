# -*- coding:utf-8 -*-
L=[3,5,7,6]
a=L[:]
L.append(1)
a.append(10)
print("The first three items in the list are:")
print(L[:3])
print("Three items form the middle of the list are:")
print(L[1:4])
print("The last three items in the list are:")
print(L[-3:])
