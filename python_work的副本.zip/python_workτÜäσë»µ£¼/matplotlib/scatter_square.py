import matplotlib.pyplot as plt
#渲染点图
def xuanran(x_values,y_values):

	plt.scatter(x_values,y_values,c=y_values,cmap=plt.cm.Blues,edgecolor='none',s=50)
	"""设置点图的属性"""
	plt.title("Square Numbers",fontsize=24)
	plt.xlabel("Value",fontsize=14)
	plt.ylabel("Square of value",fontsize=14)
	plt.tick_params(axis='both',labelsize=14)
	#设置每个坐标轴的取值范围
	plt.axis([0,1100,0,1100000])
	"""显示出设计的点图"""
	plt.show()
	
