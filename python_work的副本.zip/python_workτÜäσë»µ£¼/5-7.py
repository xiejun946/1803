# -*- coding:utf-8 -*-
favorite_fruits=["pineapple","apple","banana"]
if "apple" in favorite_fruits:
	print("you really like apple")

if "pineapple"	in favorite_fruits:
	print("you really like pineapple")
	
if "banana" in favorite_fruits:
	print("you really like banana")
	
if "orange" in favorite_fruits:
	print("you really like orange")
	
if "watermelon"	in favorite_fruits:
	print("you really like watermelon")	
		
