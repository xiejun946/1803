# -*- coding:utf-8 -*-
from random import randint
class Die():
	def __init__(self,sides=6):
		self.sides=sides
		
		
	def roll_die(self):
		"""
		daying 1 dao saizi mianshu zhijian d suijishu
		"""
		print("saizi de dianshu shi "+str(randint(1,self.sides)))
			
saizi1=Die(100)
saizi1.roll_die()
setattr(saizi1,'sides',5)
print(saizi1.sides)
