# -*- coding:utf-8 -*-
message=input("请问您想租什么车尼: byd,binli,bmw? ")
print("Let me see if i can find you a "+message)
