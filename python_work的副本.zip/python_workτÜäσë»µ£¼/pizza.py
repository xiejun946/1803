# -*- coding:utf-8 -*-
def make_pizza(*toppings):
	"""概述要制作的披萨"""
	print("Making a pizza with the following toppings:")
	for topping in toppings:
		print(" +"+topping)
		
		
