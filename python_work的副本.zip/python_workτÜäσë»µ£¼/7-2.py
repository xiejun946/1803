# -*- coding:utf-8 -*-
num=input("请输入一个数字 ")
if int(num)%10 == 0:
	print("它是10的整数倍")
else:
	print("它不是10的整数")	
