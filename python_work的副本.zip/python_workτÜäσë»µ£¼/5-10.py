# -*- coding:utf-8 -*-
current_user=["admin","guest","xiejun","tutu","gogo"]
new_user=["admin","guest","xx","oo","yy"]
for name in new_user:
	if name in current_user:
		print("请输入别的用户名，该用户名已被使用")
	else:
		print("该用户名未被使用")	
