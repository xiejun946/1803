# -*- coding:utf-8 -*-
message=input("please input somathing to me ,i will repeat to you: ")
print(message+"\n")
name=input("please enter your name: ")
print("Hello, "+name+" !")
prompt="if you tell us who you are ,we can personalize the message you see."
prompt+="\nwhat is your first name?"
name=input(prompt)
print("\nhello "+name+" !")
