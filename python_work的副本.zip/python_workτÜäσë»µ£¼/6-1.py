# -*- coding:utf-8 -*-
tutu={
    "first_name": "tu",
    "last_name": "hao",
    "age": 28,
    "city": "wuhan"             
    }

beibei={
    "first_name": "bei",
    "last_name": "bei",
    "age": 29,
    "city": "wuhan"
    }

laohao={
    "first_name": "lao",
    "last_name": "hao",
    "age": 28,
    "city": "wuhan"    
    }
    
infomation=[tutu,beibei,laohao]
for name in infomation:
	print(name)    
